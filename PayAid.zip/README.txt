1.Upload "payaid.php" file to the /modules/gateways/ folder of your WHMCS installation.
2.And upload "/callback/payaid.php" file to /modules/gateways/callback/.
3.Navigate to "Setup->Payment Gateways" to activate and configure the plugin.